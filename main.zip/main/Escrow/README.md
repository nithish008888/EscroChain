set-up

`yarn install`

`npm start`
